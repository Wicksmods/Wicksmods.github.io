# WickKeeper

> Temporary rescue for the World of Warcraft: Forever beta, where the client writes saved variables and never reads them back.

On the Forever beta no addon's settings survive a reload. The client
writes every saved variable file correctly at logout and hands back
nothing at load. It is not specific to any addon, and nothing an addon
normally does can work around it: a console variable an addon registers
lives for the session only and never reaches `Config.wtf`.

What does survive is **macros**, because they are stored on the server
rather than in your settings folder. So this keeps a copy of other
addons' saved variables inside a handful of macros and puts it back at
login.

It is meant to be thrown away. The moment the client starts loading
saved variables properly it stands down on its own and tells you so.

## What it does

- Watches the saved variables every loaded addon declares, including
  Blizzard's own.
- Writes a compressed copy into macros named `WK01`, `WK02` and so on,
  every minute while you play and again at logout.
- Puts them back at login, but **only** where the client handed over
  nothing, so a client that works is never overwritten.

## What it will not do

- It never reads, edits or deletes a macro that is not named `WKnn`.
  Your own macros are not touched.
- It uses at most 40 of your 120 account macro slots, and refuses to
  save rather than exceed that.
- Large addon databases will not fit. Settings will; bulk data such as
  item caches or quest histories will not, and it will say so.

## Timing

Macro data may not have arrived from the server on the very first login
of a session, in which case an addon that already started keeps its
empty settings. Reloading once fixes it. Reloads are the common case
and they work.

## Commands

| Command | Effect |
|---|---|
| `/keeper` | Status |
| `/keeper save` | Save now |
| `/keeper restore` | Restore now |
| `/keeper list` | What it is watching |
| `/keeper clear` | Delete its macros |

## Install

Drop the `!WicksKeeper` folder into `Interface\AddOns\`. The leading
exclamation mark matters: it makes the addon load before the ones it is
rescuing. No dependencies.

## License

MIT for code (see [LICENSE](LICENSE)). The "Wick" name and brand chrome are trademarked, see [TRADEMARK.md](https://github.com/Wicksmods/WickSuite/blob/main/TRADEMARK.md).
