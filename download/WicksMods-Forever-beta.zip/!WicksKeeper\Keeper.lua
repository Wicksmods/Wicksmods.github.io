-- WickKeeper
-- A temporary rescue for the Forever beta.
--
-- On this build the client writes every addon's saved variables at logout
-- and hands back nothing at load, so nobody's settings survive. Console
-- variables are no help: one an addon registers lives for the session
-- only and never reaches Config.wtf. What does survive is macros, because
-- they are stored on the server rather than in the settings folder.
--
-- So this keeps a copy of other addons' saved variables inside macros and
-- puts it back when the client hands over nothing. It is named with a
-- leading exclamation mark so it loads before the addons it is rescuing.
--
-- It is meant to be thrown away. The moment the client starts loading
-- saved variables properly it stands down on its own and says so.

local ADDON = ...
local Keeper = {}
_G.WickKeeper = Keeper

local PREFIX      = "WK"     -- macro names: WK01, WK02 ...
local CHUNK       = 240      -- a macro body holds 255 characters
local MAX_MACROS  = 40       -- never take more of the player's macro slots
local SAVE_EVERY  = 60       -- seconds

local ACCOUNT_MACROS = 120   -- Constants.MacroConsts.MAX_ACCOUNT_MACROS

Keeper.tracked = {}          -- global name -> addon that declared it
Keeper.restored = {}         -- global name -> true when we put it back
Keeper.enabled = true
Keeper.reason = nil

local function out(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff4FC778WickKeeper|r: " .. tostring(msg))
    end
end

-- ============================================================
-- Serialize, and base64 so a macro body stays plain text
-- ============================================================
local function ser(v, out_)
    local t = type(v)
    if t == "string" then
        out_[#out_ + 1] = "S" .. #v .. ":" .. v
    elseif t == "number" then
        out_[#out_ + 1] = "N" .. tostring(v) .. ";"
    elseif t == "boolean" then
        out_[#out_ + 1] = v and "T" or "F"
    elseif t == "table" then
        out_[#out_ + 1] = "{"
        for k, val in pairs(v) do
            local kt, vt = type(k), type(val)
            if (kt == "string" or kt == "number") and vt ~= "function" and vt ~= "userdata" then
                ser(k, out_)
                ser(val, out_)
            end
        end
        out_[#out_ + 1] = "}"
    else
        out_[#out_ + 1] = "F"
    end
end

local function deser(s, pos)
    local c = s:sub(pos, pos)
    if c == "S" then
        local len, colon = s:match("^(%d+)():", pos + 1)
        if not len then error("bad string") end
        local start = colon + 1
        len = tonumber(len)
        return s:sub(start, start + len - 1), start + len
    elseif c == "N" then
        local num, after = s:match("^([^;]+);()", pos + 1)
        if not num then error("bad number") end
        return tonumber(num), after
    elseif c == "T" then return true, pos + 1
    elseif c == "F" then return false, pos + 1
    elseif c == "{" then
        local t = {}
        pos = pos + 1
        while s:sub(pos, pos) ~= "}" do
            if pos > #s then error("unterminated") end
            local k, v
            k, pos = deser(s, pos)
            v, pos = deser(s, pos)
            t[k] = v
        end
        return t, pos + 1
    end
    error("unexpected byte")
end

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local ENC, DEC = {}, {}
for i = 1, 64 do
    local ch = B64:sub(i, i)
    ENC[i - 1] = ch
    DEC[ch] = i - 1
end

local function b64enc(s)
    local o, n = {}, 0
    for i = 1, #s, 3 do
        local a, b, c = s:byte(i, i + 2)
        local v = a * 65536 + (b or 0) * 256 + (c or 0)
        n = n + 1
        o[n] = ENC[math.floor(v / 262144)] .. ENC[math.floor(v / 4096) % 64]
            .. (b and ENC[math.floor(v / 64) % 64] or "=")
            .. (c and ENC[v % 64] or "=")
    end
    return table.concat(o)
end

local function b64dec(s)
    s = s:gsub("[^A-Za-z0-9+/]", "")
    local o, n = {}, 0
    for i = 1, #s, 4 do
        local c1, c2 = DEC[s:sub(i, i)], DEC[s:sub(i + 1, i + 1)]
        if not c1 or not c2 then break end
        local c3, c4 = DEC[s:sub(i + 2, i + 2)], DEC[s:sub(i + 3, i + 3)]
        local v = c1 * 262144 + c2 * 4096 + (c3 or 0) * 64 + (c4 or 0)
        n = n + 1
        o[n] = string.char(math.floor(v / 65536))
            .. (c3 and string.char(math.floor(v / 256) % 256) or "")
            .. (c4 and string.char(v % 256) or "")
    end
    return table.concat(o)
end

-- ============================================================
-- The macro store
-- ============================================================
-- Only macros whose name matches our prefix are ever read, written or
-- deleted. A macro the player made is never touched.

local function macroIndexesByName()
    local found = {}
    if not GetMacroInfo then return found end
    for i = 1, ACCOUNT_MACROS do
        local name = GetMacroInfo(i)
        if name and name:sub(1, #PREFIX) == PREFIX and name:match("^" .. PREFIX .. "%d+$") then
            found[name] = i
        end
    end
    return found
end

function Keeper:ReadStore()
    local mine = macroIndexesByName()
    local parts, i = {}, 1
    while true do
        local name = ("%s%02d"):format(PREFIX, i)
        local idx = mine[name]
        if not idx then break end
        local _, _, body = GetMacroInfo(idx)
        if not body or body == "" then break end
        parts[#parts + 1] = body
        i = i + 1
    end
    if #parts == 0 then return nil end
    local ok, value = pcall(function() return (deser(b64dec(table.concat(parts)), 1)) end)
    if ok and type(value) == "table" then return value end
    return nil
end

function Keeper:WriteStore(tbl)
    if not CreateMacro or not EditMacro then return false, "no macro api" end
    if InCombatLockdown() then return false, "in combat" end
    local ok, payload = pcall(function()
        local o = {}
        ser(tbl, o)
        return table.concat(o)
    end)
    if not ok then return false, "could not serialize" end
    local encoded = b64enc(payload)
    local needed = math.ceil(#encoded / CHUNK)
    if needed > MAX_MACROS then
        return false, ("too big: %d macros needed, cap is %d"):format(needed, MAX_MACROS)
    end

    local mine = macroIndexesByName()
    for i = 1, needed do
        local name = ("%s%02d"):format(PREFIX, i)
        local body = encoded:sub((i - 1) * CHUNK + 1, i * CHUNK)
        local idx = mine[name]
        if idx then
            pcall(EditMacro, idx, name, "INV_Misc_Note_01", body)
        else
            local created = select(1, pcall(CreateMacro, name, "INV_Misc_Note_01", body, false))
            if not created then return false, "could not create a macro" end
        end
    end
    -- Clear any leftovers from a previously larger save.
    local after = macroIndexesByName()
    for name, idx in pairs(after) do
        local n = tonumber(name:match("%d+"))
        if n and n > needed then pcall(DeleteMacro, idx) end
    end
    self.lastSaved = needed
    return true, needed
end

-- ============================================================
-- Which globals to look after
-- ============================================================

local function metadata(addon, field)
    if C_AddOns and C_AddOns.GetAddOnMetadata then return C_AddOns.GetAddOnMetadata(addon, field) end
    local f = rawget(_G, "GetAddOnMetadata")
    return f and f(addon, field)
end

function Keeper:Track(addon)
    if addon == ADDON then return end
    for _, field in ipairs({ "SavedVariables", "SavedVariablesPerCharacter" }) do
        local list = metadata(addon, field)
        if list then
            for name in tostring(list):gmatch("[^,%s]+") do
                self.tracked[name] = addon
            end
        end
    end
end

-- A global counts as "the client gave us something" when it holds data we
-- did not put there ourselves.
local function looksPopulated(v)
    if type(v) ~= "table" then return false end
    return next(v) ~= nil
end

function Keeper:Restore()
    if not self.enabled then return 0 end
    local store = self:ReadStore()
    if not store then return 0 end
    local n = 0
    for name, value in pairs(store) do
        if type(value) == "table" and not looksPopulated(rawget(_G, name)) then
            _G[name] = value
            self.restored[name] = true
            n = n + 1
        end
    end
    if n > 0 then self.didRestore = true end
    return n
end

function Keeper:Snapshot()
    local out_ = {}
    local count = 0
    for name in pairs(self.tracked) do
        local v = rawget(_G, name)
        if looksPopulated(v) then
            out_[name] = v
            count = count + 1
        end
    end
    return out_, count
end

function Keeper:Save(quiet)
    if not self.enabled then return false, self.reason end
    local snap, count = self:Snapshot()
    if count == 0 then return false, "nothing to save yet" end
    local ok, info = self:WriteStore(snap)
    if not ok and not quiet then out("could not save: " .. tostring(info)) end
    if ok then self.lastCount = count end
    return ok, info
end

-- If the client is loading saved variables properly, this addon is not
-- needed and should stay out of the way.
function Keeper:CheckClient()
    local populated, total = 0, 0
    for name in pairs(self.tracked) do
        total = total + 1
        if looksPopulated(rawget(_G, name)) and not self.restored[name] then
            populated = populated + 1
        end
    end
    -- Several addons arriving with their own data means the client is fine.
    if total >= 3 and populated >= 3 and not self.didRestore then
        self.enabled = false
        self.reason = "not needed: this client loads saved variables normally"
        return false
    end
    return true
end

-- ============================================================
-- Wiring
-- ============================================================
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        Keeper:Track(arg1)
        -- Macro data may not have arrived this early on a cold login, but
        -- on a reload it usually has, which is when it matters most.
        if not Keeper.tried and GetMacroInfo and GetMacroInfo(1) ~= nil then
            Keeper.tried = true
            Keeper:Restore()
        end
        return
    end
    if event == "PLAYER_LOGIN" then
        for i = 1, (C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns() or 0) do
            local name = C_AddOns.GetAddOnInfo(i)
            if name then Keeper:Track(name) end
        end
        local n = Keeper:Restore()
        Keeper:CheckClient()
        if not Keeper.enabled then
            out(Keeper.reason .. ". Nothing was changed.")
        elseif n > 0 then
            out(("restored %d saved variable%s from your macros. Reload once if an addon still looks empty."):format(n, n == 1 and "" or "s"))
        else
            out("watching " .. (function() local c = 0 for _ in pairs(Keeper.tracked) do c = c + 1 end return c end)()
                .. " saved variables. Nothing stored yet; it will save as you play.")
        end
        if C_Timer and C_Timer.NewTicker then
            C_Timer.NewTicker(SAVE_EVERY, function() Keeper:Save(true) end)
        end
        return
    end
    if event == "PLAYER_LOGOUT" then
        Keeper:Save(true)
    end
end)

SLASH_WICKKEEPER1 = "/keeper"
SLASH_WICKKEEPER2 = "/wickkeeper"
SlashCmdList["WICKKEEPER"] = function(msg)
    msg = tostring(msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "save" then
        local ok, info = Keeper:Save()
        out(ok and ("saved into %d macro%s."):format(info, info == 1 and "" or "s") or ("not saved: " .. tostring(info)))
    elseif msg == "restore" then
        local n = Keeper:Restore()
        out(n > 0 and ("restored %d. Reload for addons that already started."):format(n) or "nothing stored to restore.")
    elseif msg == "clear" then
        local mine = macroIndexesByName()
        local n = 0
        for _, idx in pairs(mine) do
            if DeleteMacro then pcall(DeleteMacro, idx); n = n + 1 end
        end
        out(("cleared %d macro%s."):format(n, n == 1 and "" or "s"))
    elseif msg == "list" then
        local names = {}
        for name in pairs(Keeper.tracked) do names[#names + 1] = name end
        table.sort(names)
        out("watching: " .. (#names > 0 and table.concat(names, ", ") or "nothing"))
    else
        local tracked = 0
        for _ in pairs(Keeper.tracked) do tracked = tracked + 1 end
        out(Keeper.enabled and ("active. Watching %d saved variables, %d macros used, %d restored this session.")
            :format(tracked, Keeper.lastSaved or 0, (function() local c = 0 for _ in pairs(Keeper.restored) do c = c + 1 end return c end)())
            or Keeper.reason)
        out("commands: save | restore | list | clear")
    end
end
