# WickKeeper - Changelog

## 0.1.0 - 2026-09-19

### First release

- Keeps other addons' saved variables in macros, which live on the
  server and therefore survive the Forever beta's saved-variable fault.
- Restores only where the client handed over nothing, so a working
  client is never overwritten.
- Never touches a macro it did not create, and caps itself at 40 of the
  120 account macro slots.
- Stands down and says so once the client loads saved variables again.
